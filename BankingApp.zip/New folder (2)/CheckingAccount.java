public class CheckingAccount extends Account {
    private static final double OVERDRAFT_LIMIT = 500.00; // Overdraft limit

    // Constructor
    public CheckingAccount(String accountNumber, String accountHolder, double initialBalance) {
        super(accountNumber, accountHolder, initialBalance);
    }

    // Overriding withdraw method to handle overdraft
    @Override
    public void withdraw(double amount) {
        if (amount > 0 && (getBalance() + OVERDRAFT_LIMIT) >= amount) {
            super.withdraw(amount);
        } else {
            System.out.println("Insufficient funds or overdraft limit reached.");
        }
    }

    // No interest calculation for checking accounts
    @Override
    public void calculateInterest() {
        // No interest for checking accounts
    }
}
