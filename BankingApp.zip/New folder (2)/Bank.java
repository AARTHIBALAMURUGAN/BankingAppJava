import java.util.HashMap;
import java.util.Map;

public class Bank {
    private Map<String, Account> accounts = new HashMap<>();

    // Add account method
    public void addAccount(Account account) {
        accounts.put(account.getAccountNumber(), account);
        System.out.println("Account added: " + account.getAccountNumber());
    }

    // Get account method
    public Account getAccount(String accountNumber) {
        return accounts.get(accountNumber);
    }

    // Display all accounts
    public void displayAllAccounts() {
        for (Account account : accounts.values()) {
            account.displayAccountInfo();
            System.out.println();
        }
    }

    // Remove account method
    public void removeAccount(String accountNumber) {
        if (accounts.containsKey(accountNumber)) {
            accounts.remove(accountNumber);
            System.out.println("Account closed: " + accountNumber);
        } else {
            System.out.println("Account not found.");
        }
    }
}
