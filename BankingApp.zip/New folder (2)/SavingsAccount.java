public class SavingsAccount extends Account {
    private static final double INTEREST_RATE = 0.03; // 3% annual interest

    // Constructor
    public SavingsAccount(String accountNumber, String accountHolder, double initialBalance) {
        super(accountNumber, accountHolder, initialBalance);
    }

    // Calculate interest
    @Override
    public void calculateInterest() {
        double interest = getBalance() * INTEREST_RATE;
        deposit(interest);
        System.out.println("Interest added: " + interest);
    }
}
