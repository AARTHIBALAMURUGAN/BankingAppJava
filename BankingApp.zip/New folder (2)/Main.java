import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Bank bank = new Bank();

        // Creating some accounts
        Account savingsAccount = new SavingsAccount("123456", "John Doe", 1000.00);
        Account checkingAccount = new CheckingAccount("654321", "Jane Smith", 1500.00);
        
        bank.addAccount(savingsAccount);
        bank.addAccount(checkingAccount);

        // Displaying all accounts
        bank.displayAllAccounts();

        // User interaction
        while (true) {
            System.out.println("1. Deposit");
            System.out.println("2. Withdraw");
            System.out.println("3. Transfer");
            System.out.println("4. Check Balance");
            System.out.println("5. Calculate Interest");
            System.out.println("6. Close Account");
            System.out.println("7. Display Account Info");
            System.out.println("8. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();

            if (choice == 8) {
                break;
            }

            System.out.print("Enter account number: ");
            String accountNumber = scanner.next();
            Account account = bank.getAccount(accountNumber);

            if (account == null) {
                System.out.println("Account not found.");
                continue;
            }

            switch (choice) {
                case 1:
                    System.out.print("Enter amount to deposit: ");
                    double depositAmount = scanner.nextDouble();
                    account.deposit(depositAmount);
                    break;
                case 2:
                    System.out.print("Enter amount to withdraw: ");
                    double withdrawAmount = scanner.nextDouble();
                    account.withdraw(withdrawAmount);
                    break;
                case 3:
                    System.out.print("Enter target account number: ");
                    String targetAccountNumber = scanner.next();
                    Account targetAccount = bank.getAccount(targetAccountNumber);
                    if (targetAccount == null) {
                        System.out.println("Target account not found.");
                        continue;
                    }
                    System.out.print("Enter amount to transfer: ");
                    double transferAmount = scanner.nextDouble();
                    account.transfer(targetAccount, transferAmount);
                    break;
                case 4:
                    System.out.println("Balance: " + account.getBalance());
                    break;
                case 5:
                    account.calculateInterest();
                    break;
                case 6:
                    bank.removeAccount(accountNumber);
                    break;
                case 7:
                    account.displayAccountInfo();
                    break;
                default:
                    System.out.println("Invalid option.");
                    break;
            }
        }
        scanner.close();
    }
}
